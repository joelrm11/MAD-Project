package com.example.flappybird;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static TextView txt_score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);  //to remove the status bar and make it full screen :KS then go to manifest file
        DisplayMetrics dm = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(dm);  //will get the info of device display
        Constants.SCREEN_WIDTH=dm.widthPixels;    //set width of display through "dm"
        Constants.SCREEN_HEIGHT=dm.heightPixels;  //set height of display through "dm" next we created BaseObject for bird and Pipe for pipe XD
        setContentView(R.layout.activity_main);

        txt_score=findViewById(R.id.txt_score);
    }
}